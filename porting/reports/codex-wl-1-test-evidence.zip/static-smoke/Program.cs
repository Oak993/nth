using Marrow.UI.Theme.Wallpapers;
using SkiaSharp;
var count = 0;
foreach (var wall in WallpaperCatalogue.All.Where(w => w.Kind == WallpaperKind.Static))
foreach (var pack in wall.Packs)
foreach (var dark in new[] { false, true })
{
    using var renderer = new WallpaperRenderer(new(WallpaperKind.Static, wall.Id, pack.Id), dark);
    using var surface = SKSurface.Create(new SKImageInfo(32, 20, SKColorType.Rgba8888, SKAlphaType.Premul));
    renderer.Draw(surface.Canvas, 32, 20);
    using var image = surface.Snapshot(); using var bitmap = SKBitmap.FromImage(image);
    if (bitmap.Pixels.Any(p => p.Alpha != 255)) throw new Exception($"{wall.Id}/{pack.Id}/{dark}: nonopaque frame");
    renderer.Draw(surface.Canvas, 32, 20);
    if (renderer.Renders != 1 || renderer.NeedsFrames) throw new Exception($"{wall.Id}/{pack.Id}/{dark}: cache/idle failure");
    count++;
}
Console.WriteLine($"Static CPU smoke: {count} pack/theme frames rendered, cached, opaque and idle.");
