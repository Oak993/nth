from pathlib import Path
import json,collections,hashlib,zipfile
root=Path('/workspace/marrow-port');ev=Path('/workspace/flake-1-review-evidence');dest=root/'porting/evidence/flake-1-review-repair'
counts=collections.defaultdict(dict)
for stage in ['before','after']:
 for group in ['App','Core','Services']:
  rows=json.loads((ev/stage/(group+'.json')).read_text());assert len(rows)==50
  c=collections.defaultdict(collections.Counter)
  for row in rows:
   assert row['tests']
   for t in row['tests']:c[t['name']][t['outcome']]+=1
  for name,outcomes in c.items():
   assert sum(outcomes.values())==50 and not(set(outcomes)-{'Passed','Failed'}),(name,outcomes)
   counts[name][stage]=dict(outcomes)
assert len(counts)==19,len(counts)
for name,record in counts.items():
 assert set(record)=={'before','after'},name
 if 'REVIEW_FixtureLockTests' in name or 'An_abandoned_publication_lock' in name:expected={'before':{'Failed':50},'after':{'Passed':50}}
 elif 'FixtureLockContentionTests' in name or 'A_live_publication_owner' in name:expected={'before':{'Passed':50},'after':{'Passed':50}}
 else:expected={'before':{'Failed':50},'after':{'Failed':50}}
 assert record==expected,(name,record)
writers=collections.defaultdict(dict)
for stage in ['before','after']:
 rows=json.loads((ev/'writers'/(stage+'.json')).read_text());assert len(rows)==200
 grouped=collections.defaultdict(collections.Counter)
 for r in rows:grouped[r['fixture']+' '+r['mode']]['Passed' if r['exit']==0 else 'Failed']+=1
 for name,result in grouped.items():
  assert result==({'Failed':50} if stage=='before' and 'abandoned' in name else {'Passed':50}),(name,result)
  writers[name][stage]=dict(result)
(dest/'counts.json').write_text(json.dumps({'status':'NOT READY','iterationsPerCase':50,'tests':dict(sorted(counts.items())),'standaloneWriters':dict(sorted(writers.items()))},indent=2)+'\n')
source=json.loads((ev/'tested-source-sha256.json').read_text())
for p,h in source['files'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
prefix=json.loads((ev/'engineering-prefix.json').read_text());assert hashlib.sha256((root/'porting/engineering_decisions.md').read_bytes()[:prefix['bytes']]).hexdigest()==prefix['sha256']
for name in ['tested-source-sha256.json','engineering-prefix.json']:(dest/name).write_bytes((ev/name).read_bytes())
binaries={}
for stage in ['before','after']:
 for group in ['App','Core','Services','UI']:
  p=ev/f'{stage}-build/bin/Marrow.{group}.Tests/debug/Marrow.{group}.Tests.dll';assert p.exists(),p
  binaries[str(p.relative_to(ev))]=hashlib.sha256(p.read_bytes()).hexdigest()
(ev/'test-binary-sha256.json').write_text(json.dumps(binaries,indent=2)+'\n')
files=set(ev.glob('*.json'))|set(ev.glob('*.log'))|set(ev.glob('*.py'))|set(ev.glob('*.cs'));files.add(ev/'port-verification.stderr')
for stage in ['before','after']:
 files.update((ev/stage).glob('*.json'))
 for group in ['App','Core','Services']:
  for i in range(1,51):files.update((ev/stage/group/f'{i:02}').glob('*'))
 files.update((ev/'writers'/stage).glob('*.cs'));files.update((ev/'writers'/stage).glob('*.csproj'));files.update((ev/'writers'/stage).glob('*.log'))
 for d in (ev/'writers'/stage/'runs').iterdir():
  for pattern in ['*.log','call-*.args','stdin-*.txt']:files.update(d.glob(pattern))
files.update((ev/'writers').glob('*.json'));files.update((ev/'writers').glob('*.log'))
for group in ['App','Core','Services','UI']:files.update((ev/'traceability'/group).glob('*'))
(ev/'evidence-file-sha256.json').write_text(json.dumps({str(p.relative_to(ev)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files) if p.is_file()},indent=2)+'\n');files.add(ev/'evidence-file-sha256.json')
with zipfile.ZipFile(dest/'runs.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):
  if p.is_file():z.write(p,str(p.relative_to(ev)))
(dest/'runs.sha256').write_text(hashlib.sha256((dest/'runs.zip').read_bytes()).hexdigest()+'  runs.zip\n')
print('Verified 19 exact cases x 50 attempts before/after, plus four standalone writer cases x 50 before/after. Source and engineering-prefix hashes match. ZIP bytes', (dest/'runs.zip').stat().st_size)
