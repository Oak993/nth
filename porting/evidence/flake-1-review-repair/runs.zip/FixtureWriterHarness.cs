#nullable enable
using System;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading;

internal static class FixtureWriterHarness
{
    private static int Main(string[] args)
    {
        string fixture = args[0], mode = args[1];
        string folder = AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        string prefix = fixture == "provider" ? "MarrowProviderProbe-" : "MarrowPiStandIn-";
        string lockName = "Local\\" + prefix + BitConverter.ToString(SHA256.HashData(Encoding.UTF8.GetBytes(folder))).Replace("-", "");
        string record = Path.Combine(folder, fixture == "provider" ? "call-0.args" : "stdin-0.txt");
        byte[] expected = Encoding.UTF8.GetBytes(fixture == "provider" ? "login\0" : "complete stdin");
        using var publication = new Mutex(false, lockName);
        Action write = fixture == "provider"
            ? () => { var result = typeof(ProviderProbeStandIn).GetMethod("Main", BindingFlags.NonPublic | BindingFlags.Static)!.Invoke(null, new object[] { new[] { "login" } }); if (!Equals(result, 0)) throw new Exception("provider fixture failed"); }
            : () => { typeof(PiStandIn).GetField("dir", BindingFlags.NonPublic | BindingFlags.Static)!.SetValue(null, folder); typeof(PiStandIn).GetMethod("Write", BindingFlags.NonPublic | BindingFlags.Static)!.Invoke(null, new object[] { "stdin-0.txt", expected }); };
        try
        {
            if (mode == "abandoned")
            {
                var owner = new Thread(() => publication.WaitOne());
                owner.Start();
                if (!owner.Join(TimeSpan.FromSeconds(30))) throw new Exception("owner failed to finish");
                write();
            }
            else
            {
                using var done = new ManualResetEventSlim();
                Exception? failure = null;
                var worker = new Thread(() => { try { write(); } catch (Exception e) { failure = e; } finally { done.Set(); } }) { IsBackground = true };
                publication.WaitOne();
                try
                {
                    worker.Start();
                    if (!SpinWait.SpinUntil(() => (worker.ThreadState & ThreadState.WaitSleepJoin) != 0 || done.IsSet, TimeSpan.FromSeconds(30))) throw new Exception("writer never reached the lock");
                    if (done.IsSet || File.Exists(record)) throw new Exception("writer bypassed a live lock owner");
                }
                finally
                {
                    publication.ReleaseMutex();
                    if (!worker.Join(TimeSpan.FromSeconds(30))) throw new Exception("writer failed to finish after release");
                }
                if (failure != null) throw failure;
            }
            if (!File.ReadAllBytes(record).AsSpan().SequenceEqual(expected)) throw new Exception("record was lost or incomplete");
            Exception? releaseFailure = null;
            var follower = new Thread(() =>
            {
                try
                {
                    using var next = new Mutex(false, lockName);
                    if (!next.WaitOne(0)) throw new Exception("writer did not release ownership");
                    next.ReleaseMutex();
                }
                catch (Exception e) { releaseFailure = e; }
            });
            follower.Start();
            if (!follower.Join(TimeSpan.FromSeconds(30))) throw new Exception("follower failed to finish");
            if (releaseFailure != null) throw releaseFailure;
            Console.WriteLine("PASS " + fixture + " " + mode);
            return 0;
        }
        catch (Exception e)
        {
            var cause = e is TargetInvocationException ? e.InnerException! : e;
            Console.Error.WriteLine(cause.GetType().Name + ": " + cause.Message);
            return 1;
        }
    }
}
