import pathlib,subprocess,concurrent.futures,json,shutil,sys
root=pathlib.Path('/workspace/flake-1-review-evidence/writers');stage=sys.argv[1];out=root/stage/'runs';out.mkdir(exist_ok=True)
records=[]
def run(fixture,mode,i):
 folder=out/f'{fixture}-{mode}-{i:02}';folder.mkdir(exist_ok=True)
 for p in (root/stage/'bin/Debug/net10.0').glob('harness.*'):shutil.copy(p,folder/p.name)
 p=subprocess.run(['/workspace/.flake-dotnet/dotnet',str(folder/'harness.dll'),fixture,mode],capture_output=True,text=True,timeout=90)
 (folder/'stdout.log').write_text(p.stdout);(folder/'stderr.log').write_text(p.stderr)
 return {'fixture':fixture,'mode':mode,'iteration':i,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for i in range(1,51):
  records.extend(pool.map(lambda case:run(*case,i),[(f,m) for f in ['provider','pi'] for m in ['abandoned','live']]))
  (root/(stage+'.json')).write_text(json.dumps(records,indent=2)+'\n')
  print(stage,i,'/50',flush=True)
