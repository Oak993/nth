import concurrent.futures, json, os, pathlib, subprocess, sys, time, xml.etree.ElementTree as ET
root=pathlib.Path('/workspace/marrow-port'); out=pathlib.Path('/workspace/flake-1-evidence')/sys.argv[1]; out.mkdir(parents=True,exist_ok=True)
groups={'CoreExtra':'FullyQualifiedName~ShellTests.RunTool_forwards_its_timeout','ServicesExtra':'FullyQualifiedName~GitTests.The_retry_test_reads|FullyQualifiedName~GitTests.A_cancelled_retry_sleep'}
env=os.environ.copy(); env['PATH']='/workspace/.flake-dotnet:'+env['PATH']; env['MARROW_PORT_DATA_DIR']='/workspace/flake-1-data'; env['DOTNET_CLI_TELEMETRY_OPTOUT']='1'
# Four independent CPU-bound processes compete with test hosts in this four-CPU cgroup.
load=[] # Existing four load workers remain active.
(out/'environment.json').write_text(json.dumps({'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'cpu_max':pathlib.Path('/sys/fs/cgroup/cpu.max').read_text(),'workers':4,'iterations':50,'sdk':subprocess.check_output(['dotnet','--version'],env=env,text=True).strip(),'filters':groups},indent=2))
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def run_group(name,selection):
    records=[]
    for i in range(1,51):
        dest=out/name/f'{i:02}'; dest.mkdir(parents=True,exist_ok=True)
        cmd=['dotnet','test',f'tests/Marrow.{name.removesuffix("Extra")}.Tests/Marrow.{name.removesuffix("Extra")}.Tests.csproj','--no-build','--no-restore','-p:EnableWindowsTargeting=true','--filter',f'FullyQualifiedName!~Native&({selection})','--logger','trx;LogFileName=run.trx','--results-directory',str(dest),'--nologo','-v:q']
        with (dest/'output.log').open('w') as log:
            p=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
        trx=dest/'run.trx'; tests=[]
        if trx.exists():
            doc=ET.parse(trx); tests=[{'name':e.attrib['testName'],'outcome':e.attrib['outcome']} for e in doc.findall('.//t:UnitTestResult',ns)]
        records.append({'iteration':i,'exit':p.returncode,'tests':tests})
        (out/(name+'.json')).write_text(json.dumps(records,indent=2))
        print(f'{name} {i}/50 exit={p.returncode} '+str({k:sum(t['outcome']==k for t in tests) for k in ['Passed','Failed']}),flush=True)
    return records
try:
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(lambda pair:run_group(*pair),groups.items()))
finally:
    for p in load: p.terminate()
    for p in load: p.wait()
