import subprocess, sys, signal
workers=[subprocess.Popen([sys.executable,'-c','while True: sum(i*i for i in range(10000))']) for _ in range(4)]
print('Four CPU load workers active',flush=True)
def stop(*args):
 for p in workers:p.terminate()
 for p in workers:p.wait()
 sys.exit(0)
signal.signal(signal.SIGTERM,stop); signal.signal(signal.SIGINT,stop)
signal.pause()
