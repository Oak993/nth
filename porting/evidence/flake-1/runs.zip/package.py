import pathlib,json,collections,hashlib,subprocess,zipfile
root=pathlib.Path('/workspace/marrow-port');ev=pathlib.Path('/workspace/flake-1-evidence');dest=root/'porting/evidence/flake-1'
selected={'before':['before/App.json','before/UI.json','before/Core-parallel.json','before/Services.json','before-extra/CoreExtra-parallel.json','before-extra/ServicesExtra.json'],'after':[f'after/{p}.json' for p in ['App','UI','Core','Services']]}
counts=collections.defaultdict(dict)
for stage,paths in selected.items():
 seen=set()
 for path in paths:
  rows=json.loads((ev/path).read_text());assert len(rows)==50,(path,len(rows))
  c=collections.defaultdict(collections.Counter)
  for row in rows:
   assert row['tests'],(path,row['iteration'])
   for t in row['tests']:c[t['name']][t['outcome']]+=1
  for name,outcomes in c.items():
   assert sum(outcomes.values())==50,(name,outcomes)
   assert not(set(outcomes)-{'Passed','Failed'}),(name,outcomes)
   assert name not in seen,name
   seen.add(name);counts[name][stage]=dict(outcomes)
 assert len(seen)==48,(stage,len(seen))
assert all(set(v)=={'before','after'} for v in counts.values())
wall=[v for k,v in counts.items() if 'WallpaperCardTests' in k][0];assert wall=={'before':{'Passed':11,'Failed':39},'after':{'Passed':50}}
for k,v in counts.items():
 if 'ComposerWorkingDotsEaseTests' in k or 'OrbRendererTests' in k or ('AppModelTurnFinishedTests' in k and 'spent_usage_limit' not in k):assert v=={'before':{'Passed':50},'after':{'Passed':50}},(k,v)
 elif 'WallpaperCardTests' not in k:assert v=={'before':{'Failed':50},'after':{'Failed':50}},(k,v)
(dest/'counts.json').write_text(json.dumps({'status':'NOT READY','iterationsPerCase':50,'cases':dict(sorted(counts.items()))},indent=2)+'\n')
manifest=json.loads((ev/'tested-source-sha256.json').read_text())
for p,h in manifest['files'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
prefix=json.loads((ev/'engineering-prefix.json').read_text());data=(root/'porting/engineering_decisions.md').read_bytes();assert hashlib.sha256(data[:prefix['bytes']]).hexdigest()==prefix['sha256']
for f in ['tested-source-sha256.json','engineering-prefix.json']:(dest/f).write_bytes((ev/f).read_bytes())
dlls={}
for group in ['App','Services','Core','UI']:
 name=f'Marrow.{group}.Tests.dll'
 before=list((root/f'tests/Marrow.{group}.Tests/bin/Debug').glob(f'*/{name}'));assert len(before)==1,before
 after=ev/f'after-build/bin/Marrow.{group}.Tests/debug/{name}';assert after.exists(),after
 for p in [before[0],after]:dlls[str(p.relative_to(ev)) if p.is_relative_to(ev) else str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
assert len(dlls)==8,dlls
(ev/'test-binary-sha256.json').write_text(json.dumps(dlls,indent=2)+'\n')
files=set()
for paths in selected.values():
 for path in paths:files.add(ev/path)
for group in ['App','UI','Services']:
 for i in range(1,51):files.update((ev/'before'/group/f'{i:02}').glob('*'))
for group,stage,prefixname in [('Core','before','parallel-'),('CoreExtra','before-extra','parallel-'),('ServicesExtra','before-extra','')]:
 for i in range(1,51):files.update((ev/stage/group/f'{prefixname}{i:02}').glob('*'))
for group in ['App','UI','Core','Services']:
 for i in range(1,51):files.update((ev/'after'/group/f'{i:02}').glob('*'))
for folder in ['helpers','smoke-fixed','traceability']:
 files.update((ev/folder).glob('*'))
files.update(ev.glob('*.log'));files.update(ev.glob('*.py'));files.update(ev.glob('*.json'));files.add(ev/'port-verification.stderr')
for stage in ['before','after','before-extra']:files.add(ev/stage/'environment.json')
files.update((ev/'provider-publication').glob('*.json'));files.update((ev/'provider-publication').glob('*.py'));files.update((ev/'provider-publication').glob('*.log'))
for stage in ['before','after']:
 files.update((ev/'provider-publication'/stage).glob('*.cs'));files.update((ev/'provider-publication'/stage).glob('*.csproj'));files.update((ev/'provider-publication'/stage).glob('*.log'))
files.update((ev/'pi-publication').glob('*.log'));files.update((ev/'pi-publication').glob('*.json'));files.update((ev/'pi-publication').glob('*.csproj'))
with zipfile.ZipFile(dest/'runs.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(files):
  if f.is_file():z.write(f,str(f.relative_to(ev)))
(dest/'runs.sha256').write_text(hashlib.sha256((dest/'runs.zip').read_bytes()).hexdigest()+'  runs.zip\n')
print('48 exact cases: 50 before + 50 after each; zero skips; source and prefix hashes verified. ZIP', (dest/'runs.zip').stat().st_size,'bytes')
