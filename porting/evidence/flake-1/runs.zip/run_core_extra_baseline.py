import concurrent.futures, json, os, pathlib, subprocess, time, xml.etree.ElementTree as ET
root=pathlib.Path('/workspace/marrow-port'); out=pathlib.Path('/workspace/flake-1-evidence/before-extra/CoreExtra'); env=os.environ.copy(); env['PATH']='/workspace/.flake-dotnet:'+env['PATH']; env['MARROW_PORT_DATA_DIR']='/workspace/flake-1-data'
selection='FullyQualifiedName~ShellTests.RunTool_forwards_its_timeout'
def run(i):
 dest=out/f'parallel-{i:02}'; dest.mkdir(parents=True,exist_ok=True)
 cmd=['dotnet','test','tests/Marrow.Core.Tests/Marrow.Core.Tests.csproj','--no-build','--no-restore','-p:EnableWindowsTargeting=true','--filter','FullyQualifiedName!~Native&('+selection+')','--logger','trx;LogFileName=run.trx','--results-directory',str(dest),'--nologo','-v:q']
 with (dest/'output.log').open('w') as log: p=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
 tests=[{'name':r.attrib['testName'],'outcome':r.attrib['outcome']} for r in ET.parse(dest/'run.trx').findall('.//t:UnitTestResult',ns)] if (dest/'run.trx').exists() else []
 print(i,p.returncode,flush=True); return {'iteration':i,'exit':p.returncode,'tests':tests}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool: records=list(pool.map(run,range(1,51)))
(out.parent/'CoreExtra-parallel.json').write_text(json.dumps(records,indent=2))
