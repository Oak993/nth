import collections, concurrent.futures, json, os, pathlib, shutil, subprocess
root=pathlib.Path('/workspace/flake-1-evidence/provider-publication'); env=os.environ.copy();env['PATH']='/workspace/.flake-dotnet:'+env['PATH']; records={}
for stage in ['before','after']:
 records[stage]=[]
 for i in range(50):
  folder=root/stage/f'run-{i:02}';folder.mkdir(exist_ok=True)
  for f in (root/stage/'bin/Debug/net10.0').glob('probe.*'): shutil.copy(f,folder/f.name)
  def launch(n):
   p=subprocess.run(['dotnet',str(folder/'probe.dll'),str(n)],env=env,capture_output=True,text=True)
   return {'argv':str(n),'exit':p.returncode,'stderr':p.stderr}
  with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool: exits=list(pool.map(launch,range(16)))
  calls=[p.read_bytes().decode().split('\0')[0] for p in sorted(folder.glob('call-*.args'))]
  ok=all(p['exit']==0 for p in exits) and collections.Counter(calls)==collections.Counter(map(str,range(16)))
  records[stage].append({'iteration':i+1,'passed':ok,'calls':calls,'processes':exits})
  (root/'results.json').write_text(json.dumps(records,indent=2))
  print(stage,i+1,'PASS' if ok else 'FAIL',len(calls),flush=True)
